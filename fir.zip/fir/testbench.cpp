#include <stdio.h>
#include "fir.h"

#define LENGTH 25

int main() {
    data_t input_real[LENGTH];
    data_t input_img[LENGTH];

    data_t kernel_real[KERNEL_SIZE];
    data_t kernel_img[KERNEL_SIZE];

    acc_t output_real;
    acc_t output_img;

    //Create array with all 1 for real and all 0 for imaginary
    for (int i = 0; i < LENGTH; i++) {
        input_real[i] = 1;
        input_img[i] = 0;
    }

    //Create coefficients 0 through 24
    for (int i = 0; i < KERNEL_SIZE; i++) {
        kernel_real[i] = i + 1;
        kernel_img[i] = i + 1;
    }

    //Put imputs through fir and output results
    for (int i = 0; i < LENGTH; i++) {
        complex_fir(
            input_real[i],
            input_img[i],
            kernel_real,
            kernel_img,
            &output_real,
            &output_img
        );

        printf("output %d real: %d img: %d\n",
               i,
               (int)output_real,
               (int)output_img);
    }

    return 0;
}