#ifndef FIR_H
#define FIR_H

#include <ap_int.h>

#define KERNEL_SIZE 25

typedef ap_int<16> data_t;
typedef ap_int<32> acc_t;

void complex_fir(
    data_t input_real,
    data_t input_img,
    data_t kernel_real[KERNEL_SIZE],
    data_t kernel_img[KERNEL_SIZE],
    acc_t *output_real,
    acc_t *output_img
);

#endif