#include "fir.h"

void complex_fir(
    data_t input_real,
    data_t input_img,
    data_t kernel_real[KERNEL_SIZE],
    data_t kernel_img[KERNEL_SIZE],
    acc_t *output_real,
    acc_t *output_img
) {
    #pragma HLS INLINE off

    static data_t shift_real[KERNEL_SIZE];
    static data_t shift_img[KERNEL_SIZE];

    #pragma HLS ARRAY_PARTITION variable=shift_real complete
    #pragma HLS ARRAY_PARTITION variable=shift_img complete
    #pragma HLS ARRAY_PARTITION variable=kernel_real complete
    #pragma HLS ARRAY_PARTITION variable=kernel_img complete

    acc_t acc_real = 0;
    acc_t acc_img = 0;

    //Shift old samples
    SHIFT_LOOP:
    for (int i = KERNEL_SIZE - 1; i > 0; i--) {
        #pragma HLS UNROLL
        shift_real[i] = shift_real[i - 1];
        shift_img[i] = shift_img[i - 1];
    }

    //Insert newest sample
    shift_real[0] = input_real;
    shift_img[0] = input_img;

    //Accumulate values
    MAC_LOOP:
    for (int i = 0; i < KERNEL_SIZE; i++) {
        #pragma HLS UNROLL factor=5
        acc_real += shift_real[i] * kernel_real[i] - shift_img[i]  * kernel_img[i];
        acc_img  += shift_real[i] * kernel_img[i] + shift_img[i]  * kernel_real[i];
    }

    *output_real = acc_real;
    *output_img = acc_img;
}