#include <stdio.h>
#include "cordic.h"

int main() {

    FIXED_POINT x = 2.0;   // example input
    FIXED_POINT y = 1.0;

    FIXED_POINT mag, theta;

    cordic_rotater(x, y, &mag, &theta);

    printf("mag = %f, theta = %f\n",
           mag.to_float(),
           theta.to_float());

    return 0;
}