#include "cordic.h"

// Lookup table for arctan(2^-i)
// These values are in radians
const FIXED_POINT cordic_phase[NUM_ITER] = {
    0.7853981633974483,   // atan(2^0)
    0.4636476090008061,   // atan(2^-1)
    0.2449786631268641,   // atan(2^-2)
    0.1243549945467614,   // atan(2^-3)
    0.0624188099959574,   // atan(2^-4)
    0.0312398334302683,   // atan(2^-5)
    0.0156237286204768,   // atan(2^-6)
    0.0078123410601011,   // atan(2^-7)
    0.0039062301319669,   // atan(2^-8)
    0.0019531225164788,   // atan(2^-9)
    0.0009765621895593,   // atan(2^-10)
    0.0004882812111949,   // atan(2^-11)
    0.0002441406201494,   // atan(2^-12)
    0.0001220703118937,   // atan(2^-13)
    0.0000610351561742,   // atan(2^-14)
    0.0000305175781155    // atan(2^-15)
};

void cordic_rotater(
    FIXED_POINT cos_in,
    FIXED_POINT sin_in,
    FIXED_POINT *mag_out,
    FIXED_POINT *theta_out
) {
#pragma HLS INLINE off

    // Initial state
    FIXED_POINT current_cos = cos_in;
    FIXED_POINT current_sin = sin_in;
    FIXED_POINT theta_rotated = 0.0;

    // Constants
    FIXED_POINT ninety = 1.5708;   // π/2
    FIXED_POINT circle = 6.28319;  // 2π
    FIXED_POINT scaling_factor = 0.60735; // CORDIC gain correction

    // Quadrant correction
    if (current_cos < 0 && current_sin > 0) {
        // Quadrant 2 → rotate +90
        FIXED_POINT x = current_cos;
        current_cos = -current_sin;
        current_sin = x;
        theta_rotated += ninety;
    }
    else if (current_cos < 0 && current_sin < 0) {
        // Quadrant 3 → rotate +180
        current_cos = -current_cos;
        current_sin = -current_sin;
        theta_rotated += (FIXED_POINT)3.14159;
    }
    else if (current_cos > 0 && current_sin < 0) {
        // Quadrant 4 → rotate -90
        FIXED_POINT x = current_cos;
        current_cos = current_sin;
        current_sin = -x;
        theta_rotated -= ninety;
    }

    // Iterative CORDIC vectoring
    CORDIC_LOOP:
    for (int i = 0; i < NUM_ITER; i++) {
#pragma HLS PIPELINE II=1

        FIXED_POINT x_shift = current_cos >> i;
        FIXED_POINT y_shift = current_sin >> i;

        if (current_sin > 0) {
            // Rotate clockwise
            current_cos += y_shift;
            current_sin -= x_shift;
            theta_rotated += cordic_phase[i];
        } else {
            // Rotate counterclockwise
            current_cos -= y_shift;
            current_sin += x_shift;
            theta_rotated -= cordic_phase[i];
        }
    }

    FIXED_POINT mag = current_cos * scaling_factor;

    // Normalize angle
    if (theta_rotated > circle)
        theta_rotated -= circle;
    if (theta_rotated < -circle)
        theta_rotated += circle;

    *mag_out = mag;
    *theta_out = theta_rotated;
}