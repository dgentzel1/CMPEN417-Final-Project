#ifndef CORDIC_H
#define CORDIC_H

#include <ap_fixed.h>
#include <hls_stream.h>

#define NUM_ITER 16

typedef ap_fixed<32,20> FIXED_POINT;

// Lookup table for arctan(2^-i) values
extern const FIXED_POINT cordic_phase[NUM_ITER];

// CORDIC rotator function
void cordic_rotater(
    FIXED_POINT cos_in,
    FIXED_POINT sin_in,
    FIXED_POINT *mag_out,
    FIXED_POINT *theta_out
);

#endif