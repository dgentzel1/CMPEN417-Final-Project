set ModuleHierarchy {[{
"Name" : "cordic_rotater", "RefName" : "cordic_rotater","ID" : "0","Type" : "sequential",
"SubInsts" : [
	{"Name" : "grp_cordic_rotater_Pipeline_VITIS_LOOP_65_1_fu_124", "RefName" : "cordic_rotater_Pipeline_VITIS_LOOP_65_1","ID" : "1","Type" : "sequential",
		"SubLoops" : [
		{"Name" : "VITIS_LOOP_65_1","RefName" : "VITIS_LOOP_65_1","ID" : "2","Type" : "pipeline"},]},]
}]}