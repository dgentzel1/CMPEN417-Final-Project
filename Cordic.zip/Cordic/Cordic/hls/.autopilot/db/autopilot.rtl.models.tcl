set SynModuleInfo {
  {SRCNAME cordic_rotater_Pipeline_VITIS_LOOP_65_1 MODELNAME cordic_rotater_Pipeline_VITIS_LOOP_65_1 RTLNAME cordic_rotater_cordic_rotater_Pipeline_VITIS_LOOP_65_1
    SUBMODULES {
      {MODELNAME cordic_rotater_cordic_rotater_Pipeline_VITIS_LOOP_65_1_cordic_phase_ROM_AUTO_1R RTLNAME cordic_rotater_cordic_rotater_Pipeline_VITIS_LOOP_65_1_cordic_phase_ROM_AUTO_1R BINDTYPE storage TYPE rom IMPL auto LATENCY 2 ALLOW_PRAGMA 1}
      {MODELNAME cordic_rotater_flow_control_loop_pipe_sequential_init RTLNAME cordic_rotater_flow_control_loop_pipe_sequential_init BINDTYPE interface TYPE internal_upc_flow_control INSTNAME cordic_rotater_flow_control_loop_pipe_sequential_init_U}
    }
  }
  {SRCNAME cordic_rotater MODELNAME cordic_rotater RTLNAME cordic_rotater IS_TOP 1
    SUBMODULES {
      {MODELNAME cordic_rotater_sparsemux_7_2_15_1_1 RTLNAME cordic_rotater_sparsemux_7_2_15_1_1 BINDTYPE op TYPE sparsemux IMPL onehotencoding_realdef}
      {MODELNAME cordic_rotater_sparsemux_7_2_32_1_1 RTLNAME cordic_rotater_sparsemux_7_2_32_1_1 BINDTYPE op TYPE sparsemux IMPL onehotencoding_realdef}
    }
  }
}
