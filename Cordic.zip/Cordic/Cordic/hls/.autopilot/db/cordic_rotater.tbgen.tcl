set moduleName cordic_rotater
set isTopModule 1
set isCombinational 0
set isDatapathOnly 0
set isPipelined 0
set isPipelined_legacy 0
set pipeline_type none
set FunctionProtocol ap_ctrl_hs
set restart_counter_num 0
set isOneStateSeq 0
set ProfileFlag 0
set StallSigGenFlag 0
set isEnableWaveformDebug 1
set hasInterrupt 0
set DLRegFirstOffset 0
set DLRegItemOffset 0
set svuvm_can_support 1
set cdfgNum 4
set C_modelName {cordic_rotater}
set C_modelType { void 0 }
set ap_memory_interface_dict [dict create]
set C_modelArgList {
	{ cos_in int 32 regular  }
	{ sin_in int 32 regular  }
	{ mag_out int 32 regular {pointer 1}  }
	{ theta_out int 32 regular {pointer 1}  }
}
set hasAXIMCache 0
set l_AXIML2Cache [list]
set AXIMCacheInstDict [dict create]
set C_modelArgMapList {[ 
	{ "Name" : "cos_in", "interface" : "wire", "bitwidth" : 32, "direction" : "READONLY"} , 
 	{ "Name" : "sin_in", "interface" : "wire", "bitwidth" : 32, "direction" : "READONLY"} , 
 	{ "Name" : "mag_out", "interface" : "wire", "bitwidth" : 32, "direction" : "WRITEONLY"} , 
 	{ "Name" : "theta_out", "interface" : "wire", "bitwidth" : 32, "direction" : "WRITEONLY"} ]}
# RTL Port declarations: 
set portNum 12
set portList { 
	{ ap_clk sc_in sc_logic 1 clock -1 } 
	{ ap_rst sc_in sc_logic 1 reset -1 active_high_sync } 
	{ ap_start sc_in sc_logic 1 start -1 } 
	{ ap_done sc_out sc_logic 1 predone -1 } 
	{ ap_idle sc_out sc_logic 1 done -1 } 
	{ ap_ready sc_out sc_logic 1 ready -1 } 
	{ cos_in sc_in sc_lv 32 signal 0 } 
	{ sin_in sc_in sc_lv 32 signal 1 } 
	{ mag_out sc_out sc_lv 32 signal 2 } 
	{ mag_out_ap_vld sc_out sc_logic 1 outvld 2 } 
	{ theta_out sc_out sc_lv 32 signal 3 } 
	{ theta_out_ap_vld sc_out sc_logic 1 outvld 3 } 
}
set NewPortList {[ 
	{ "name": "ap_clk", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "clock", "bundle":{"name": "ap_clk", "role": "default" }} , 
 	{ "name": "ap_rst", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "reset", "bundle":{"name": "ap_rst", "role": "default" }} , 
 	{ "name": "ap_start", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "start", "bundle":{"name": "ap_start", "role": "default" }} , 
 	{ "name": "ap_done", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "predone", "bundle":{"name": "ap_done", "role": "default" }} , 
 	{ "name": "ap_idle", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "done", "bundle":{"name": "ap_idle", "role": "default" }} , 
 	{ "name": "ap_ready", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "ready", "bundle":{"name": "ap_ready", "role": "default" }} , 
 	{ "name": "cos_in", "direction": "in", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "cos_in", "role": "default" }} , 
 	{ "name": "sin_in", "direction": "in", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "sin_in", "role": "default" }} , 
 	{ "name": "mag_out", "direction": "out", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "mag_out", "role": "default" }} , 
 	{ "name": "mag_out_ap_vld", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "outvld", "bundle":{"name": "mag_out", "role": "ap_vld" }} , 
 	{ "name": "theta_out", "direction": "out", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "theta_out", "role": "default" }} , 
 	{ "name": "theta_out_ap_vld", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "outvld", "bundle":{"name": "theta_out", "role": "ap_vld" }}  ]}

set ArgLastReadFirstWriteLatency {
	cordic_rotater {
		cos_in {Type I LastRead 0 FirstWrite -1}
		sin_in {Type I LastRead 0 FirstWrite -1}
		mag_out {Type O LastRead -1 FirstWrite 4}
		theta_out {Type O LastRead -1 FirstWrite 3}
		cordic_phase {Type I LastRead -1 FirstWrite -1}}
	cordic_rotater_Pipeline_VITIS_LOOP_65_1 {
		current_cos {Type I LastRead 0 FirstWrite -1}
		current_sin_2 {Type I LastRead 0 FirstWrite -1}
		storemerge5_ph_cast {Type I LastRead 0 FirstWrite -1}
		theta_rotated_out {Type O LastRead -1 FirstWrite 1}
		current_cos_4_out {Type O LastRead -1 FirstWrite 1}
		cordic_phase {Type I LastRead -1 FirstWrite -1}}}

set hasDtUnsupportedChannel 0

set PerformanceInfo {[
	{"Name" : "Latency", "Min" : "22", "Max" : "22"}
	, {"Name" : "Interval", "Min" : "23", "Max" : "23"}
]}

set PipelineEnableSignalInfo {[
]}

set Spec2ImplPortList { 
	cos_in { ap_none {  { cos_in in_data 0 32 } } }
	sin_in { ap_none {  { sin_in in_data 0 32 } } }
	mag_out { ap_vld {  { mag_out out_data 1 32 }  { mag_out_ap_vld out_vld 1 1 } } }
	theta_out { ap_vld {  { theta_out out_data 1 32 }  { theta_out_ap_vld out_vld 1 1 } } }
}

set maxi_interface_dict [dict create]

# RTL port scheduling information:
set fifoSchedulingInfoList { 
}

# RTL bus port read request latency information:
set busReadReqLatencyList { 
}

# RTL bus port write response latency information:
set busWriteResLatencyList { 
}

# RTL array port load latency information:
set memoryLoadLatencyList { 
}
