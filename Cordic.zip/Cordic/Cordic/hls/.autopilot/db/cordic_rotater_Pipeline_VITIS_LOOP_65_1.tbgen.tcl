set moduleName cordic_rotater_Pipeline_VITIS_LOOP_65_1
set isTopModule 0
set isCombinational 0
set isDatapathOnly 0
set isPipelined 1
set isPipelined_legacy 1
set pipeline_type loop_auto_rewind
set FunctionProtocol ap_ctrl_hs
set restart_counter_num 0
set isOneStateSeq 0
set ProfileFlag 0
set StallSigGenFlag 0
set isEnableWaveformDebug 1
set hasInterrupt 0
set DLRegFirstOffset 0
set DLRegItemOffset 0
set svuvm_can_support 1
set cdfgNum 4
set C_modelName {cordic_rotater_Pipeline_VITIS_LOOP_65_1}
set C_modelType { void 0 }
set ap_memory_interface_dict [dict create]
set C_modelArgList {
	{ current_cos int 32 regular  }
	{ current_sin_2 int 32 regular  }
	{ storemerge5_ph_cast int 15 regular  }
	{ theta_rotated_out int 32 regular {pointer 1}  }
	{ current_cos_4_out int 32 regular {pointer 1}  }
}
set hasAXIMCache 0
set l_AXIML2Cache [list]
set AXIMCacheInstDict [dict create]
set C_modelArgMapList {[ 
	{ "Name" : "current_cos", "interface" : "wire", "bitwidth" : 32, "direction" : "READONLY"} , 
 	{ "Name" : "current_sin_2", "interface" : "wire", "bitwidth" : 32, "direction" : "READONLY"} , 
 	{ "Name" : "storemerge5_ph_cast", "interface" : "wire", "bitwidth" : 15, "direction" : "READONLY"} , 
 	{ "Name" : "theta_rotated_out", "interface" : "wire", "bitwidth" : 32, "direction" : "WRITEONLY"} , 
 	{ "Name" : "current_cos_4_out", "interface" : "wire", "bitwidth" : 32, "direction" : "WRITEONLY"} ]}
# RTL Port declarations: 
set portNum 13
set portList { 
	{ ap_clk sc_in sc_logic 1 clock -1 } 
	{ ap_rst sc_in sc_logic 1 reset -1 active_high_sync } 
	{ ap_start sc_in sc_logic 1 start -1 } 
	{ ap_done sc_out sc_logic 1 predone -1 } 
	{ ap_idle sc_out sc_logic 1 done -1 } 
	{ ap_ready sc_out sc_logic 1 ready -1 } 
	{ current_cos sc_in sc_lv 32 signal 0 } 
	{ current_sin_2 sc_in sc_lv 32 signal 1 } 
	{ storemerge5_ph_cast sc_in sc_lv 15 signal 2 } 
	{ theta_rotated_out sc_out sc_lv 32 signal 3 } 
	{ theta_rotated_out_ap_vld sc_out sc_logic 1 outvld 3 } 
	{ current_cos_4_out sc_out sc_lv 32 signal 4 } 
	{ current_cos_4_out_ap_vld sc_out sc_logic 1 outvld 4 } 
}
set NewPortList {[ 
	{ "name": "ap_clk", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "clock", "bundle":{"name": "ap_clk", "role": "default" }} , 
 	{ "name": "ap_rst", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "reset", "bundle":{"name": "ap_rst", "role": "default" }} , 
 	{ "name": "ap_start", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "start", "bundle":{"name": "ap_start", "role": "default" }} , 
 	{ "name": "ap_done", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "predone", "bundle":{"name": "ap_done", "role": "default" }} , 
 	{ "name": "ap_idle", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "done", "bundle":{"name": "ap_idle", "role": "default" }} , 
 	{ "name": "ap_ready", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "ready", "bundle":{"name": "ap_ready", "role": "default" }} , 
 	{ "name": "current_cos", "direction": "in", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "current_cos", "role": "default" }} , 
 	{ "name": "current_sin_2", "direction": "in", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "current_sin_2", "role": "default" }} , 
 	{ "name": "storemerge5_ph_cast", "direction": "in", "datatype": "sc_lv", "bitwidth":15, "type": "signal", "bundle":{"name": "storemerge5_ph_cast", "role": "default" }} , 
 	{ "name": "theta_rotated_out", "direction": "out", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "theta_rotated_out", "role": "default" }} , 
 	{ "name": "theta_rotated_out_ap_vld", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "outvld", "bundle":{"name": "theta_rotated_out", "role": "ap_vld" }} , 
 	{ "name": "current_cos_4_out", "direction": "out", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "current_cos_4_out", "role": "default" }} , 
 	{ "name": "current_cos_4_out_ap_vld", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "outvld", "bundle":{"name": "current_cos_4_out", "role": "ap_vld" }}  ]}

set ArgLastReadFirstWriteLatency {
	cordic_rotater_Pipeline_VITIS_LOOP_65_1 {
		current_cos {Type I LastRead 0 FirstWrite -1}
		current_sin_2 {Type I LastRead 0 FirstWrite -1}
		storemerge5_ph_cast {Type I LastRead 0 FirstWrite -1}
		theta_rotated_out {Type O LastRead -1 FirstWrite 1}
		current_cos_4_out {Type O LastRead -1 FirstWrite 1}
		cordic_phase {Type I LastRead -1 FirstWrite -1}}}

set hasDtUnsupportedChannel 0

set PerformanceInfo {[
	{"Name" : "Latency", "Min" : "18", "Max" : "18"}
	, {"Name" : "Interval", "Min" : "16", "Max" : "16"}
]}

set PipelineEnableSignalInfo {[
	{"Pipeline" : "0", "EnableSignal" : "ap_enable_pp0"}
]}

set Spec2ImplPortList { 
	current_cos { ap_none {  { current_cos in_data 0 32 } } }
	current_sin_2 { ap_none {  { current_sin_2 in_data 0 32 } } }
	storemerge5_ph_cast { ap_none {  { storemerge5_ph_cast in_data 0 15 } } }
	theta_rotated_out { ap_vld {  { theta_rotated_out out_data 1 32 }  { theta_rotated_out_ap_vld out_vld 1 1 } } }
	current_cos_4_out { ap_vld {  { current_cos_4_out out_data 1 32 }  { current_cos_4_out_ap_vld out_vld 1 1 } } }
}
